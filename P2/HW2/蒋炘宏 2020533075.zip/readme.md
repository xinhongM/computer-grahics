# k_means.py and superpixiel.py for question1
# VSA using meshlab to implement instead of python code
# test.jpg, test2.jpg are two picture for testing